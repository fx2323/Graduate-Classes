package traffic.data;

import junit.framework.TestCase;

public class RoadSegmentTEST extends TestCase {

	
	public void testConstructorAndAttributes() {
		
	}
}
