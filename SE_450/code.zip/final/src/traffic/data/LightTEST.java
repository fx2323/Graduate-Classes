package traffic.data;

import java.awt.Color;
import traffic.agent.TimeServerQueue;
import junit.framework.TestCase;

public class LightTEST extends TestCase  {

	public void testConstructorAndAttributes() {
		boolean v_yellow=false;
		boolean v_red=false;
		boolean v_green=false;
		boolean h_yellow=false;
		boolean h_green=false;
		boolean h_red=false;
		SettingsData testData = new SettingsData.SettingsDataBuilder().build();
		TimeServerQueue timeServer= new TimeServerQueue();
	
		Light test = new Light(testData,timeServer);
		
		//check that one light is green while other is red
		if(test.vertical().getColor().equals(Color.RED)){
			assertTrue(test.horizontal().getColor().equals(Color.GREEN));
		}
		else{
			assertTrue(test.vertical().getColor().equals(Color.GREEN));
			assertTrue(test.horizontal().getColor().equals(Color.RED));
		}
		double time=0;
		while(time<=(testData.lightGreenTimeMax()+testData.lightYellowTimeMax())*2){
			
			if(test.vertical().getColor().equals(Color.YELLOW)){v_yellow=true;}
			else if(test.vertical().getColor().equals(Color.RED)){v_red=true;}
			else if(test.vertical().getColor().equals(Color.GREEN)){v_green=true;}
			
			
			if(test.horizontal().getColor().equals(Color.YELLOW)){h_yellow=true;}
			else if(test.horizontal().getColor().equals(Color.RED)){h_red=true;}
			else if(test.horizontal().getColor().equals(Color.GREEN)){h_green=true;}
			
			timeServer.run(testData.timeStep());
			assertTrue(checkCrossColors(test.vertical().getColor(),test.horizontal().getColor()));
			time+=testData.timeStep();
		}
		
		//make sure that all colors are visited at least once
		assertTrue(v_yellow);
		assertTrue(v_red);
		assertTrue(v_green);
		assertTrue(h_yellow);
		assertTrue(h_green);
		assertTrue(h_red);
		
	}
	
	private boolean checkCrossColors(Color vertical, Color horizontial){
		if(vertical.equals(Color.RED) && (horizontial.equals(Color.YELLOW) || horizontial.equals(Color.GREEN))){
			return true;
		}
		if(horizontial.equals(Color.RED) && (vertical.equals(Color.YELLOW) || vertical.equals(Color.GREEN))){
			return true;
		}
		return false;
	}
}
