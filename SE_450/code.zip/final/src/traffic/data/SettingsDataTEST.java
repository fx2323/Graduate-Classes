package traffic.data;

import junit.framework.TestCase;


public class SettingsDataTEST extends TestCase  {
	

	public void testConstructorAndAttributes() {
		SettingsData testData = new SettingsData.SettingsDataBuilder().build();
		
		//test the default values
		assertTrue(testData.timeStep()==.1);
		assertTrue(testData.runTime()==1000.0);
		assertTrue(testData.rows()==2);
		assertTrue(testData.columns()==3);
		assertTrue(testData.pattern().equals("alternating"));
		assertTrue(testData.carEntryRateMin()==2.0);
		assertTrue(testData.carEntryRateMax()==25.0);
		assertTrue(testData.roadSegmentLengthMin()==200.0);
		assertTrue(testData.roadSegmentLengthMax()==500.0);
		assertTrue(testData.intersectionLengthMin()==10.0);
		assertTrue(testData.intersectionLengthMax()==15.0);
		assertTrue(testData.carLengthMin()==5.0);
		assertTrue(testData.carLengthMax()==10.0);
		assertTrue(testData.carMaxVelocityMin()==10.0);
		assertTrue(testData.carMaxVelocityMax()==30.0);
		assertTrue(testData.carStopDistanceMin()==.5);
		assertTrue(testData.carStopDistanceMax()==5.0);
		assertTrue(testData.carBrakeDistanceMin()==9.0);
		assertTrue(testData.carBrakeDistanceMax()==10.0);
		assertTrue(testData.lightGreenTimeMin()==30.0);
		assertTrue(testData.lightGreenTimeMax()==180.0);
		assertTrue(testData.lightYellowTimeMin()==4.0);
		assertTrue(testData.lightYellowTimeMax()==5.0);
		assertEquals(
				"Simulation time step (seconds)       [0.1]\n"+
				"Simulation run time (seconds)        [1000.0]\n"+
				"Grid size (number of roads)          [row=2,column=3]\n"+
				"Traffic pattern                      [alternating]\n"+
				"Car entry rate (seconds/car)         [min=2.0,max=25.0]\n"+
				"Road segment length (meters)         [min=200.0,max=500.0]\n"+
				"Intersection length (meters)         [min=10.0,max=15.0]\n"+
				"Car length (meters)                  [min=5.0,max=10.0]\n"+
				"Car maximum velocity (meters/second) [min=10.0,max=30.0]\n"+
				"Car stop distance (meters)           [min=0.5,max=5.0]\n"+
				"Car brake distance (meters)          [min=9.0,max=10.0]\n"+
				"Traffic light green time (seconds)   [min=30.0,max=180.0]\n"+
				"Traffic light yellow time (seconds)  [min=4.0,max=5.0]\n"
				,
				testData.toString()
				);
		
	}
	
	public void testSettingsDataBuider() {
		//TODO test the data builder with different values then the default cases
	}

}
