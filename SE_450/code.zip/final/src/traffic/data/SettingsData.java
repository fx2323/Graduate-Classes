package traffic.data;

public class SettingsData {
	private double _timeStep;
	private double _runTime;
	private int _rows;
	private int _columns;
	private String _pattern;
	private double _carEntryRateMin;
	private double _carEntryRateMax;
	private double _roadSegmentLengthMin;
	private double _roadSegmentLengthMax;
	private double _intersectionLengthMin;
	private double _intersectionLengthMax;
	private double _carLengthMin;
	private double _carLengthMax;
	private double _carMaxVelocityMin;
	private double _carMaxVelocityMax;
	private double _carStopDistanceMin;
	private double _carStopDistanceMax;
	private double _carBrakeDistanceMin;
	private double _carBrakeDistanceMax;
	private double _lightGreenTimeMin;
	private double _lightGreenTimeMax;
	private double _lightYellowTimeMin;
	private double _lightYellowTimeMax;
	
	
	public SettingsData(SettingsDataBuilder builder){
		_timeStep=builder._timeStep;
		_runTime=builder._runTime;
		_rows=builder._rows;
		_columns=builder._columns;
		_pattern=builder._pattern;
		_carEntryRateMin=builder._carEntryRateMin;
		_carEntryRateMax=builder._carEntryRateMax;
		_roadSegmentLengthMin=builder._roadSegmentLengthMin;
		_roadSegmentLengthMax=builder._roadSegmentLengthMax;
		_intersectionLengthMin=builder._intersectionLengthMin;
		_intersectionLengthMax=builder._intersectionLengthMax;
		_carLengthMin=builder._carLengthMin;
		_carLengthMax=builder._carLengthMax;
		_carMaxVelocityMin=builder._carMaxVelocityMin;
		_carMaxVelocityMax=builder._carMaxVelocityMax;
		_carStopDistanceMin=builder._carStopDistanceMin;
		_carStopDistanceMax=builder._carStopDistanceMax;
		_carBrakeDistanceMin=builder._carBrakeDistanceMin;
		_carBrakeDistanceMax=builder._carBrakeDistanceMax;
		_lightGreenTimeMin=builder._lightGreenTimeMin;
		_lightGreenTimeMax=builder._lightGreenTimeMax;
		_lightYellowTimeMin=builder._lightYellowTimeMin;
		_lightYellowTimeMax=builder._lightYellowTimeMax;
	}
	
	
	public double timeStep(){
		return _timeStep;
	}
	public double runTime(){
		return _runTime;
	}
	
	public int rows(){
		return _rows;
	}
	
	public int columns(){
		return _columns;
	}
	
	public String pattern(){
		return _pattern;
	}
	
	public double carEntryRateMin(){
		return _carEntryRateMin;
	}
	
	public double carEntryRateMax(){
		return _carEntryRateMax;
	}
	
	public double roadSegmentLengthMin(){
		return _roadSegmentLengthMin;
	}
	
	public double roadSegmentLengthMax(){
		return _roadSegmentLengthMax;
	}
	
	public double intersectionLengthMin(){
		return _intersectionLengthMin;
	}
	
	public double intersectionLengthMax(){
		return _intersectionLengthMax;
	}
	
	public double carLengthMin(){
		return _carLengthMin;
	}
	
	public double carLengthMax(){
		return _carLengthMax;
	}
	
	public double carMaxVelocityMin(){
		return _carMaxVelocityMin;
	}
	
	public double carMaxVelocityMax(){
		return _carMaxVelocityMax;
	}
	
	public double carStopDistanceMin(){
		return _carStopDistanceMin;
	}
	
	public double carStopDistanceMax(){
		return _carStopDistanceMax;
	}
	
	public double carBrakeDistanceMin(){
		return _carBrakeDistanceMin;
	}
	public double carBrakeDistanceMax(){
		return _carBrakeDistanceMax;
	}
	
	public double lightGreenTimeMin(){
		return _lightGreenTimeMin;
	}
	
	public double lightGreenTimeMax(){
		return _lightGreenTimeMax;
	}
	
	public double lightYellowTimeMin(){
		return _lightYellowTimeMin;
	}
	
	public double lightYellowTimeMax(){
		return _lightYellowTimeMax;
	}
	
	public String toString(){
		int length = "Car maximum velocity (meters/second) ".length();
		
		return 
				String.format("%"+ - length+"s","Simulation time step (seconds)") +"["+_timeStep+"]\n" +
				String.format("%"+ - length+"s","Simulation run time (seconds)") +"["+_runTime+"]\n" + 
				String.format("%"+ - length+"s","Grid size (number of roads)") +"[row="+_rows + ",column="+_columns+"]\n" +
				String.format("%"+ - length+"s","Traffic pattern") +"["+_pattern+"]\n" +
				String.format("%"+ - length+"s","Car entry rate (seconds/car)") +"[min="+_carEntryRateMin+",max="+_carEntryRateMax+"]\n" +
				String.format("%"+ - length+"s","Road segment length (meters)") +"[min="+_roadSegmentLengthMin+",max="+_roadSegmentLengthMax+"]\n" +
				String.format("%"+ - length+"s","Intersection length (meters)") +"[min="+_intersectionLengthMin+",max="+_intersectionLengthMax+"]\n" +
				String.format("%"+ - length+"s","Car length (meters)") +"[min="+_carLengthMin+",max="+_carLengthMax+"]\n" +
				String.format("%"+ - length+"s","Car maximum velocity (meters/second)") +"[min="+_carMaxVelocityMin+",max="+_carMaxVelocityMax+"]\n" +
				String.format("%"+ - length+"s","Car stop distance (meters)") +"[min="+_carStopDistanceMin+",max="+_carStopDistanceMax+"]\n" +
				String.format("%"+ - length+"s","Car brake distance (meters)") +"[min="+_carBrakeDistanceMin+",max="+_carBrakeDistanceMax+"]\n" +
				String.format("%"+ - length+"s","Traffic light green time (seconds)") +"[min="+_lightGreenTimeMin+",max="+_lightGreenTimeMax+"]\n" +
				String.format("%"+ - length+"s","Traffic light yellow time (seconds)") +"[min="+_lightYellowTimeMin+",max="+_lightYellowTimeMax+"]\n"
				
				;
	}

	public static class SettingsDataBuilder{
		
		private double _timeStep=0.1;
		private double _runTime=1000.0;
		private int _rows=2;
		private int _columns=3;
		private String _pattern="alternating";
		private double _carEntryRateMin=2.0;
		private double _carEntryRateMax=25.0;
		private double _roadSegmentLengthMin=200.0;
		private double _roadSegmentLengthMax=500.0;
		private double _intersectionLengthMin=10.0;
		private double _intersectionLengthMax=15.0;
		private double _carLengthMin=5.0;
		private double _carLengthMax=10.0;
		private double _carMaxVelocityMin=10.0;
		private double _carMaxVelocityMax=30.0;
		private double _carStopDistanceMin=0.5;
		private double _carStopDistanceMax=5.0;
		private double _carBrakeDistanceMin=9.0;
		private double _carBrakeDistanceMax=10.0;
		private double _lightGreenTimeMin=30.0;
		private double _lightGreenTimeMax=180.0;
		private double _lightYellowTimeMin=4.0;
		private double _lightYellowTimeMax=5.0;
		
		public SettingsDataBuilder(){}
		public SettingsDataBuilder(SettingsData oldValues){
			_timeStep=oldValues._timeStep;
			_runTime=oldValues._runTime;
			_rows=oldValues._rows;
			_columns=oldValues._columns;
			_pattern=oldValues._pattern;
			_carEntryRateMin=oldValues._carEntryRateMin;
			_carEntryRateMax=oldValues._carEntryRateMax;
			_roadSegmentLengthMin=oldValues._roadSegmentLengthMin;
			_roadSegmentLengthMax=oldValues._roadSegmentLengthMax;
			_intersectionLengthMin=oldValues._intersectionLengthMin;
			_intersectionLengthMax=oldValues._intersectionLengthMax;
			_carLengthMin=oldValues._carLengthMin;
			_carLengthMax=oldValues._carLengthMax;
			_carMaxVelocityMin=oldValues._carMaxVelocityMin;
			_carMaxVelocityMax=oldValues._carMaxVelocityMax;
			_carStopDistanceMin=oldValues._carStopDistanceMin;
			_carStopDistanceMax=oldValues._carStopDistanceMax;
			_carBrakeDistanceMin=oldValues._carBrakeDistanceMin;
			_carBrakeDistanceMax=oldValues._carBrakeDistanceMax;
			_lightGreenTimeMin=oldValues._lightGreenTimeMin;
			_lightGreenTimeMax=oldValues._lightGreenTimeMax;
			_lightYellowTimeMin=oldValues._lightYellowTimeMin;
			_lightYellowTimeMax=oldValues._lightYellowTimeMax;
		}
		
		public SettingsDataBuilder _timeStep(double timeStep ){
			_timeStep=timeStep;
			return this;
		}
		
		public SettingsDataBuilder _runTime(double runTime ){
			_runTime=runTime;
			return this;
		}
		public SettingsDataBuilder _rows(int rows ){
			_rows=rows;
			return this;
		}
		public SettingsDataBuilder _columns(int columns ){
			_columns=columns;
			return this;
		}
		public SettingsDataBuilder _pattern(String pattern){
			_pattern=pattern;
			return this;
		}
		
		
		public SettingsDataBuilder _roadSegmentLengthMin(double min){
			_roadSegmentLengthMin=min;
			return this;
		}		
		public SettingsDataBuilder _roadSegmentLengthMax(double max){
			_roadSegmentLengthMax=max;
			return this;
		}


		
		public SettingsDataBuilder _carEntryRateMin(double min){
			_carEntryRateMin=min;
			return this;
		}	
		public SettingsDataBuilder _carEntryRateMax(double max){
			_carEntryRateMax=max;
			return this;
		}
		
		

		public SettingsDataBuilder _intersectionLengthMin(double min){
			_intersectionLengthMin=min;
			return this;
		}	
		public SettingsDataBuilder _intersectionLengthMax(double max){
			_intersectionLengthMax=max;
			return this;
		}	
		
		
		public SettingsDataBuilder _carLengthMin(double min){
			_carLengthMin=min;
			return this;
		}	
		public SettingsDataBuilder _carLengthMax(double max){
			_carLengthMax=max;
			return this;
		}	
		
		
		public SettingsDataBuilder _carMaxVelocityMin(double min){
			_carMaxVelocityMin=min;
			return this;
		}	
		public SettingsDataBuilder _carMaxVelocityMax(double max){
			_carMaxVelocityMax=max;
			return this;
		}	

		
		public SettingsDataBuilder _carStopDistanceMin(double min){
			_carStopDistanceMin=min;
			return this;
		}	
		public SettingsDataBuilder _carStopDistanceMax(double max){
			_carStopDistanceMax=max;
			return this;
		}	
		
		public SettingsDataBuilder _carBrakeDistanceMin(double min){
			_carBrakeDistanceMin=min;
			return this;
		}	
	
		public SettingsDataBuilder _carBrakeDistanceMax(double max){
			_carBrakeDistanceMax=max;
			return this;
		}
		
		
		public SettingsDataBuilder _lightGreenTimeMin(double min){
			_lightGreenTimeMin=min;
			return this;
		}
		public SettingsDataBuilder _lightGreenTimeMax(double max){
			_lightGreenTimeMax=max;
			return this;
		}	
		
		public SettingsDataBuilder _lightYellowTimeMin(double min){
			_lightYellowTimeMin=min;
			return this;
		}
		public SettingsDataBuilder _lightYellowTimeMax(double max){
			_lightYellowTimeMax=max;
			return this;
		}	
		
		
		public SettingsData build(){
			return new SettingsData(this);
		}

	}
	
	
}
