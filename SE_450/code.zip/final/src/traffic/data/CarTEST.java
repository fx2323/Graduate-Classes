package traffic.data;


import junit.framework.TestCase;
import java.awt.Color;

public class CarTEST extends TestCase  {
	
	public void testConstructorAndAttributes() {
		SettingsData testData = new SettingsData.SettingsDataBuilder().build();
		//since the values are randomly generated but based off the SettingData the constructor and attributes is tested a few times
		for(int i=0; i<1000; i++){
			Car testCar = new Car(testData);
			//test that attributes return a value between min and max
			assertTrue(testCar.getPosition()==0);
			assertTrue(testCar.length()>=testData.carLengthMin() && testCar.length()<=testData.carLengthMax());
			assertTrue(testCar.maxVelocity()>=testData.carMaxVelocityMin() && testCar.maxVelocity()<=testData.carMaxVelocityMax());
			assertTrue(testCar.stopDistance()>=testData.carStopDistanceMin() && testCar.stopDistance()<=testData.carStopDistanceMax());
			assertTrue(testCar.brakeDistance()>=testData.carBrakeDistanceMin() && testCar.brakeDistance()<=testData.carBrakeDistanceMax());
			
			//test that a Color is returned
			assertTrue(testCar.getColor().getClass().equals(Color.black.getClass()));
		}
		
		
		
		
	}

}
