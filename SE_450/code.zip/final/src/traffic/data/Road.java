package traffic.data;
import traffic.agent.Agent;
import traffic.agent.TimeServerQueue;
import java.util.Random;

public class Road implements Agent{
	private SettingsData _settings;
	private double _source;
	private double _lastCarCreatedTime=0;
	private boolean _reverse;
	private RoadSegment Start=null;
	private RoadSegment End=null;
	private TimeServerQueue _timeServer;
	
	public Road(SettingsData settings, boolean reverse, TimeServerQueue timeServer) {
		_settings=settings;
		_reverse=reverse;
		_timeServer=timeServer;
		Random rn = new Random();
		_source=_settings.carEntryRateMin()+rn.nextDouble()*(_settings.carEntryRateMax()-_settings.carEntryRateMin());
		_timeServer.enqueue(timeServer.currentTime(), this);
	}
	
	public void addRoadSegment(RoadSegment roadSegment){
		// builds a double linked list
		
		if(_reverse==false){
			if(Start==null){
				Start=roadSegment;
			}else{
				End._next=roadSegment;
				roadSegment._prev=End;
			}
			End=roadSegment;
		}else{
			if(End==null){
				End=roadSegment;
			}else{
				roadSegment._next=Start;
				Start._prev=roadSegment;
			}
			Start=roadSegment;
		}

	}

	private boolean canAddCar(){
		if(Start.getCars().isEmpty()){
			return true;
		}
		return Start.getCars().get(Start.getCars().size()-1).getPosition()>_settings.carLengthMax();
	}
	


	public void run() {
		if((_timeServer.currentTime()-_lastCarCreatedTime)>_source && canAddCar()){
			Start.accept(new Car(_settings));
			_lastCarCreatedTime=_timeServer.currentTime();
			_timeServer.enqueue(_timeServer.currentTime()+_source, this);
		}else{
			_timeServer.enqueue(_timeServer.currentTime()+_settings.timeStep(), this);
		}
		
	}

}
