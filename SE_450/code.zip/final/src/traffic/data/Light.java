package traffic.data;

import java.awt.Color;
import java.util.Random;

import traffic.agent.TimeServerQueue;


public class Light {
	private LightObj _verticalLight;
	private LightObj _horizontialLight;
	
	public Light (SettingsData settings, TimeServerQueue timeServer ) {
		_verticalLight=new LightObj(settings,timeServer);
		_horizontialLight= new LightObj(settings,timeServer);
		_verticalLight.setRedTime(_horizontialLight);
		_horizontialLight.setRedTime(_verticalLight);
		
		Random rn = new Random();
		//sets the light randomly 
		if(rn.nextDouble()<.5){
			_verticalLight.setStartColor(Color.GREEN);
			_horizontialLight.setStartColor(Color.RED);
		}
		else{
			_verticalLight.setStartColor(Color.RED);
			_horizontialLight.setStartColor(Color.GREEN);
		}
		timeServer.enqueue(timeServer.currentTime(), _verticalLight);
		timeServer.enqueue(timeServer.currentTime(), _horizontialLight);
	}
	
	public LightObj horizontal(){
		return _horizontialLight;
	}
	
	public LightObj vertical(){
		return _verticalLight;
	}
	
	public Color getState() {
		return _horizontialLight.getColor();
	}
}
