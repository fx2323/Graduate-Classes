package traffic.data;

import java.awt.Color;
import java.util.Random;
import traffic.agent.TimeServerQueue;
import traffic.agent.Agent;

public class LightObj implements Agent {
	private Color _color;
	private Color[] _lightColor=new Color[3];
	private double[] _lightTime=new double[3];;
	private double _greenTime;
	private double _yellowTime;
	private double _redTime;
	private int _count=0;
	private TimeServerQueue _timeServer;
	
	public LightObj(SettingsData settings, TimeServerQueue timeServer){

		Random rn = new Random();
		_greenTime=settings.lightGreenTimeMin() +rn.nextDouble()*(settings.lightGreenTimeMax()-settings.lightGreenTimeMin());
		_yellowTime=settings.lightYellowTimeMin() + rn.nextDouble() * (settings.lightYellowTimeMax()-settings.lightYellowTimeMin());
		_timeServer=timeServer;
	}
		
	public void setRedTime( LightObj that){
		_redTime=that._greenTime+that._yellowTime;
	}
	public void setStartColor(Color color){
		_color=color;
		
		if(color.equals(Color.RED)){
			_lightColor[0]=Color.RED;
			_lightColor[1]=Color.GREEN;
			_lightColor[2]=Color.YELLOW;
			
			_lightTime[0]=_redTime;
			_lightTime[1]=_greenTime;
			_lightTime[2]=_yellowTime;
			
		}
		if(color.equals(Color.GREEN)){
			_lightColor[0]=Color.GREEN;
			_lightColor[1]=Color.YELLOW;
			_lightColor[2]=Color.RED;
			
			_lightTime[0]=_greenTime;
			_lightTime[1]=_yellowTime;
			_lightTime[2]=_redTime;
		}
	}

	public void run(){
		_color=_lightColor[(_count)%3];
		_timeServer.enqueue(_timeServer.currentTime()+_lightTime[(_count)%3], this);
		_count++;
	}

	public Color getColor(){
		return _color;
		
	}
	

}
