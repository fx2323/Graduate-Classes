package traffic.data;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;

import traffic.agent.Agent;
import traffic.agent.TimeServerQueue;

public class RoadSegment implements Agent{
	private double _length;
	private List<Car> _cars;
	private   List<Car> _prevCars;
	protected RoadSegment _next=null;
	protected RoadSegment _prev=null;
	private final SettingsData _settings;
	private TimeServerQueue _timeServer;
	private LightObj _light;
	private RoadSegment _crossTraffic;
	
	
	public static class RoadSegmentBuilder{
		private final SettingsData _settings;
		private TimeServerQueue _timeServer;
		private LightObj _light;
		private RoadSegment _crossTraffic;
		private double _length;
		
		public RoadSegmentBuilder(SettingsData settings, TimeServerQueue timeServer){
			_settings=settings;
			_timeServer=timeServer;
			Random rn = new Random();
			_length =_settings.roadSegmentLengthMin()+ rn.nextDouble()*(_settings.roadSegmentLengthMax()-_settings.roadSegmentLengthMin());
		}
		public RoadSegmentBuilder _light(LightObj light){
			_light=light;
			Random rn = new Random();
			_length=_settings.intersectionLengthMin()+ rn.nextDouble()*(_settings.intersectionLengthMax()-_settings.intersectionLengthMin());
			return this;
		}
		public RoadSegmentBuilder _crossTraffic(RoadSegment crossTraffic){
			_crossTraffic=crossTraffic;
			return this;
		}
		public RoadSegment build(){
			return new RoadSegment(this);
		}
	}
	
	public RoadSegment(RoadSegmentBuilder builder){
		_settings=builder._settings;
		_timeServer=builder._timeServer;
		_cars = new ArrayList<Car>();
		_length=builder._length;
		_light=builder._light;
		_crossTraffic=builder._crossTraffic;
		//make sure the crossTraffic is set up both ways
		if(_crossTraffic!=null){
			_crossTraffic._crossTraffic=this;
		}
	}

	
	
	
	protected void accept(Car car) {
		if(_cars.isEmpty()){
			_timeServer.enqueue(_timeServer.currentTime()+_settings.timeStep(), this);
		}
		_cars.add(car);
	}
	
	public double getLength(){
		return _length;
	}

	public List<Car> getCars(){
		return _cars;
	}
	
	
	
	public void run(){
		_prevCars=_cars;
		ListIterator<Car> itr = _prevCars.listIterator(0);
		
		_cars = new ArrayList<Car>();
		while(itr.hasNext()){
			updateCar( itr.next());
		}
	}
	
		private void updateCar(Car car){
			double distance =newDistanceTraveled(car);
			
			RoadSegment current = this;
			double newPosition= distance + car.getPosition();
			//car needs to be passed to next roadSegment
			if((newPosition+ car.length())>(current._length)){
				
				newPosition-=_length;
				
				//car reached sink
				if(current._next==null){
					car=null;
					return;
				}
				else{
					//car moves to next road
					current._next.accept(car);
					car.setPosition(newPosition);
					return;
				}
			//car stays on the same road and moves
			}else if(newPosition!=car.getPosition()){ 
				car.setPosition(newPosition);
			}
			//car stays on the same road and moves
			current.accept(car);
			return;
		}


		private double newDistanceTraveled(Car car){
			double velocity=(car.maxVelocity()/(car.brakeDistance()-car.stopDistance()))*(Obstacle(car)- car.stopDistance());
			velocity=Math.max(0.0, velocity);
			velocity=Math.min(car.maxVelocity(), velocity);
			
			return velocity*_settings.timeStep();
		}
		
		private double Obstacle(Car car){
			
			//search current road segment and find next car
			if(_prevCars.indexOf(car)!=0){ //if index is 0 then it is leading car on that road segment
				return _prevCars.get(_prevCars.indexOf(car)-1).getPosition()-(car.getPosition()+car.length());
			}else{
				//search each of the next road segments
				RoadSegment current = _next;
				double distance=-(car.getPosition()+car.length());
				while(current!=null){
					
					//update new distance values
					distance= distance +current._prev._length;
					
					if( current._light!=null){
						//first check red light or yellow and distance is greater than Stop distance or light has crossTraffic 
						if(
								current._light.getColor().equals(Color.RED) ||
								(current._light.getColor().equals(Color.YELLOW) && distance>=car.brakeDistance())
						){
							return distance;
						}

						//checks to see that their is no car at cross traffic light or part in the light and the next road
						if(!current._crossTraffic._cars.isEmpty()){
							return distance;
						}
						//checks to see if the car is part on the next road  an part in the cross traffic road segment
						if(!current._crossTraffic._next._cars.isEmpty()){
							if(current._crossTraffic._next._cars.get(current._crossTraffic._next._cars.size()-1).getPosition()<0){
								return distance;
							}
						}
					
					}
					//take distance from value of last car on the new road segment
					if (!current._cars.isEmpty()){
						return distance+current._cars.get(current._cars.size()-1).getPosition();
					}
					
					//check next road segment
					current=current._next;	
				}
				return Double.MAX_VALUE;
			}
		}
	
}
