package traffic.data;



import java.awt.Color;
import java.util.Random;


/**
 * A car remembers its position from the beginning of its road.
 * Cars have random velocity and random movement pattern:
 * when reaching the end of a road it will be removed.
 */
public class Car{
	private final SettingsData _settings;
	private double _distance;
	private double _length;
	private double _maxVelocity;
	private double _stopDistance;
	private double _brakeDistance;
	private java.awt.Color _color = new java.awt.Color((int)Math.ceil(Math.random()*255),(int)Math.ceil(Math.random()*255),(int)Math.ceil(Math.random()*255));
	
	public Car(SettingsData settings){
		_settings=settings;
		Random rn = new Random();
		_distance=0;
		_length=_settings.carLengthMin() + rn.nextDouble()*(_settings.carLengthMax()-_settings.carLengthMin());
		_maxVelocity=_settings.carMaxVelocityMin() + rn.nextDouble()*(_settings.carMaxVelocityMax()-_settings.carMaxVelocityMin());
		_stopDistance=_settings.carStopDistanceMin() + rn.nextDouble()* (_settings.carStopDistanceMax()-_settings.carStopDistanceMin());
		_brakeDistance=_settings.carBrakeDistanceMin()+ rn.nextDouble()* (_settings.carBrakeDistanceMax()-_settings.carBrakeDistanceMin());
	}
	
	
	public double length(){
		return _length;
	}
	
	public double maxVelocity(){
		return _maxVelocity;
	}
	
	public double stopDistance(){
		return _stopDistance;
	}
	
	public double brakeDistance(){
		return _brakeDistance;
	}

	public double getPosition() {
		return _distance;
	}

	public Color getColor() {
		return _color;
	}
	
	public boolean equals(Object that){
		return this==that;
	}
	
	public void setPosition(double newDistance){
		_distance=newDistance;
	}
	
}
