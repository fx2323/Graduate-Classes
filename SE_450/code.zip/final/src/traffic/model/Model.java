package traffic.model;


import traffic.util.Animator;
import traffic.agent.TimeServerQueue;
import traffic.data.Road;
import traffic.data.Light;
import traffic.data.Car;
import traffic.data.RoadSegment;
import traffic.data.SettingsData;

/**
 * An example to model for a simple visualization.
 * The model contains roads organized in a matrix.
 * See {@link #Model(AnimatorBuilder, int, int)}.
 */
public class Model {
  private Animator _animator;
  private TimeServerQueue _timeServer;
  private boolean _disposed;
  private double _time;
  private SettingsData _settings;

  /** Creates a model to be visualized using the <code>builder</code>.
   *  If the builder is null, no visualization is performed.
   *  The number of <code>rows</code> and <code>columns</code>
   *  indicate the number of {@link Light}s, organized as a 2D
   *  matrix.  These are separated and surrounded by horizontal and
   *  vertical {@link Road}s.  For example, calling the constructor with 1
   *  row and 2 columns generates a model of the form:
   *  <pre>
   *     |  |
   *   --@--@--
   *     |  |
   *  </pre>
   *  where <code>@</code> is a {@link Light}, <code>|</code> is a
   *  vertical {@link Road} and <code>--</code> is a horizontal {@link Road}.
   *  Each road has one {@link Car}.
   *
   *  <p>
   *  The {@link AnimatorBuilder} is used to set up an {@link
   *  Animator}.
   *  {@link AnimatorBuilder#getAnimator()} is registered as
   *  an observer of a timeserverQueue.
   *  <p>
   */
  public Model(AnimatorBuilder builder, SettingsData settings)  {
    if(settings==null){
    	throw new IllegalArgumentException();
    }
	
	if (settings.rows() < 0 || settings.columns()< 0 || (settings.rows() == 0 && settings.columns() == 0)) {
      
    }
    if (builder == null) {
      builder = new NullAnimatorBuilder();
    }
    _timeServer= new TimeServerQueue();
    _settings=settings;
    setup(builder, settings.rows(), settings.columns());
    _animator = builder.getAnimator();
    _timeServer.addObserver(_animator);
    _time=0;
  }

  /**
   * Run the simulation for <code>duration</code> model seconds.
   */
  public void run() { 
    if (_disposed)
      throw new IllegalStateException();

    while( _time<_settings.runTime() ) {
    	 _timeServer.run(_settings.timeStep());
    	_time=_time+_settings.timeStep();
    }
  }

  /**
   * Throw away this model.
   */
  public void dispose() {
    _animator.dispose();
    _disposed = true;
  }

  /**
   * Construct the model, establishing correspondences with the visualizer.
   */
  private void setup(AnimatorBuilder builder, int rows, int columns) {
   
    Light[][] intersections = new Light[rows][columns];
    RoadSegment[][] crossTraffic =new RoadSegment[rows][columns];
        
    // Add Lights
    for (int i=0; i<rows; i++) {
      for (int j=0; j<columns; j++) {
        intersections[i][j] = new Light(_settings,_timeServer);
        builder.addLight(intersections[i][j], i, j);
      }
    }

    // Add Horizontal Roads
    boolean eastToWest = false;
    for (int i=0; i<rows; i++) {

    	//starts a new Road each Pass
    	Road r = new Road(_settings,eastToWest,_timeServer);
    	
    	//fills in each segment
      for (int j=0; j<=columns; j++) {
    	RoadSegment l = new RoadSegment.RoadSegmentBuilder(_settings,_timeServer).build();
        builder.addHorizontalRoad(l, i, j, eastToWest);

        
        //builds the linked list in Roads correctly
        r.addRoadSegment(l);
        if(j<columns){
        	crossTraffic[i][j]=new RoadSegment.RoadSegmentBuilder(_settings,_timeServer)._light(intersections[i][j].horizontal()).build();
        	r.addRoadSegment(crossTraffic[i][j]);
        }
      }
      if(_settings.pattern().equals("alternating")){
    	  eastToWest = !eastToWest;
      }
    }

    // Add Vertical Roads
    boolean southToNorth = false;
    for (int j=0; j<columns; j++) {
    	
    	//starts a new Road each Pass
    	Road r = new Road(_settings,southToNorth,_timeServer);
    	
    	//fills in each segment
      for (int i=0; i<=rows; i++) {
    	RoadSegment l = new RoadSegment.RoadSegmentBuilder(_settings,_timeServer).build();
        builder.addVerticalRoad(l, i, j, southToNorth);

        
        //builds the double linked list in Roads
        r.addRoadSegment(l);
        if(i<rows){ //if light is present add it
        	r.addRoadSegment(new RoadSegment.RoadSegmentBuilder(_settings,_timeServer)._light(intersections[i][j].vertical())._crossTraffic(crossTraffic[i][j]).build());
        }
        
      }
      
      //changes the roads direction if 
      if(_settings.pattern().equals("alternating")){
    	southToNorth = !southToNorth;  
      }
      
    }
  }
}
