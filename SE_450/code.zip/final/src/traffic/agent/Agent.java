package traffic.agent;

public interface Agent {
  public void run();
}
