package traffic.ui;

public interface UIMenuAction {
  public void run();
}
