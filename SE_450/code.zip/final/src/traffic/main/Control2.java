package traffic.main;





import traffic.ui.*;
import traffic.data.SettingsData;
import traffic.data.SettingsData.SettingsDataBuilder;



class Control2 {
	  private static final int EXITED = 0;
	  private static final int EXIT = 1;
	  private static final int START = 2;
	  private static final int NUMSTATES = 15;
	  private UIMenu[] _menus;
	  private int _state;

	  private UIForm _getMinMax;
	  private UIForm  _getPattern; 
	  private UIForm _getGrid;
	  private UIForm _getNewValue;
	  private UIFormTest _numberTest;
	  private UIFormTest _stringTest;
	  private SettingsDataBuilder _builder;
	  private UI _ui;
	  
	  Control2(SettingsData settingsData, UI ui) {
		_builder = new SettingsData.SettingsDataBuilder(settingsData);
	    _ui = ui;

	    _menus = new UIMenu[NUMSTATES];
	    _state = START;
	    addSTART(START);
	    addEXIT(EXIT);
	    

	    _numberTest = new UIFormTest() {
	        public boolean run(String input) {
	          try {
	            Integer.parseInt(input);
	            return true;
	          } catch (NumberFormatException e) {
	            return false;
	          }
	        }
	      };
	    _stringTest = new UIFormTest() {
	        public boolean run(String input) {
	          return ! "".equals(input.trim());
	        }
	      };
	  
	    UIFormBuilder f4 = new UIFormBuilder();
	    f4.add("", _numberTest);
	    _getNewValue = f4.toUIForm("Enter new Value");
	    
	    UIFormBuilder f3 = new UIFormBuilder();
	    f3.add("Rows:", _numberTest);
	    f3.add("Columns:", _numberTest);
	    _getGrid = f3.toUIForm("Enter Rows and Columns");
	    
	    UIFormBuilder f2 = new UIFormBuilder();
	    f2.add("New Pattern:",  _stringTest);
	    _getPattern = f2.toUIForm("Enter New Pattern");
	    
	    UIFormBuilder f = new UIFormBuilder();
	    f.add("Min:", _numberTest);
	    f.add("Max:", _numberTest);
	    _getMinMax = f.toUIForm("Enter Min/Max");
	    

	    
	    
	    
	  }
	  
	  boolean checkMinMax(String[] result){
		  if(Double.valueOf(result[0])>0 && Double.valueOf(result[1])>0 && Double.valueOf(result[0])<=Double.valueOf(result[1])){
			  return true;
		  }
		  System.out.println("Min and max values can't be 0 nor can max be less than min.");
		  return false;
	  }
	 
	  boolean checkNewValue(String[] result){
		  if(Double.valueOf(result[0])>0){
			  return true;
		  }
		  System.out.println("Values need to be greater than 0.");
		  return false;
	  }
	  
	  boolean checkGrid(String[] result){
		  if(Integer.valueOf(result[0])>=0 && Integer.valueOf(result[0])>=0){
			  return true;
		  }
		  System.out.print("Rows and Columns can't have values less than 0.");
		  return false;
	  }
	  
	  boolean checkPattern(String[] result){
		  if(result[0].equals("simple") || result[0].equals("alternative")){
			  return true;
		  }
		  System.out.println("Values must me 'simple' or 'alternative'.");
		  return false;
	  }

	 public SettingsData getSettings(){
		 return _builder.build();
	 }

	void run() {
	    try {
	      while (_state != EXITED) {
	        _ui.processMenu(_menus[_state]);
	      }
	    } catch (UIError e) {
	      _ui.displayError("UI closed");
	    }
	  }
	  
	  private void addSTART(int stateNum) {
	    UIMenuBuilder m = new UIMenuBuilder();
	    
	    m.add("Default",
	      new UIMenuAction() {
	        public void run() {
	          _ui.displayError("doh!");
	        }
	      });
	    m.add("Show current values",
	      new UIMenuAction() {
	        public void run() {
	        	System.out.println(_builder.build().toString());
	        }
	      });
	    m.add("Simulation time step",
	  	      new UIMenuAction() {
	  	        public void run() {
	  	        	String[] result1 = _ui.processForm(_getNewValue);
	  	        	if(checkNewValue(result1)){
	  	        		_builder=_builder._timeStep(Double.valueOf(result1[0]));	
	  	        	}
	  	        	
	  	        }
	  	      });
	    m.add("Simulation run time",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	String[] result1 = _ui.processForm(_getNewValue);
		  	        	if(checkNewValue(result1)){
		  	        		_builder=_builder._runTime(Double.valueOf(result1[0]));	
		  	        	}
		  	        	
		  	        }
		  	      });
	    m.add("Grid size",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	String[] result1 = _ui.processForm(_getGrid);
		  	        	if(checkGrid(result1)){
		  	        		_builder=_builder._rows(Integer.valueOf(result1[0]))._columns(Integer.valueOf(result1[1]));
		  	        	}

		  	        }
		  	      });
	    m.add("Traffic pattern",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	String[] result1 = _ui.processForm(_getPattern);
		  	        	if(checkPattern(result1)){
		  	        		_builder=_builder._pattern(result1[0]);
		  	        	}
		  	        	
		  	        }
		  	      });
	    m.add("Car entry rate",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	String[] result1 = _ui.processForm(_getMinMax);
		  	        	if(checkMinMax(result1)){
		  	        		_builder=_builder._carEntryRateMin(Double.valueOf(result1[0]))._carEntryRateMax(Double.valueOf(result1[1]));
		  	        	}
		  	        	
		  	        }
		  	      });
	    m.add("Road segment length",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	String[] result1 = _ui.processForm(_getMinMax);
		  	        	if(checkMinMax(result1)){
		  	        		_builder=_builder._roadSegmentLengthMin(Double.valueOf(result1[0]))._roadSegmentLengthMax(Double.valueOf(result1[1]));        		
		  	        	}

		  	        }
		  	      });
	    m.add("Intersection length",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	String[] result1 = _ui.processForm(_getMinMax);
		  	        	if(checkMinMax(result1)){
		  	        		_builder=_builder._intersectionLengthMin(Double.valueOf(result1[0]))._intersectionLengthMax(Double.valueOf(result1[1]));	  	        		
		  	        	}

		  	        }
		  	      });
	    m.add("Car length",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	String[] result1 = _ui.processForm(_getMinMax);
		  	        	if(checkMinMax(result1)){
		  	        		_builder=_builder._carLengthMin(Double.valueOf(result1[0]))._carLengthMax(Double.valueOf(result1[1]));
		  	        	}

		  	        }
		  	      });
	    m.add("Car maximum velocity",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	String[] result1 = _ui.processForm(_getMinMax);
		  	        	if(checkMinMax(result1)){
		  	        		_builder=_builder._carMaxVelocityMin(Double.valueOf(result1[0]))._carMaxVelocityMax(Double.valueOf(result1[1]));
		  	        	}

		  	        }
		  	      });
	    m.add("Car stop distance",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	String[] result1 = _ui.processForm(_getMinMax);
		  	        	if(checkMinMax(result1)){
		  	        		_builder=_builder._carStopDistanceMin(Double.valueOf(result1[0]))._carStopDistanceMax(Double.valueOf(result1[1]));	  	        		
		  	        	}

		  	        }
		  	      });
	    m.add("Car brake distance",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	String[] result1 = _ui.processForm(_getMinMax);
		  	        	if(checkMinMax(result1)){
		  	        		_builder=_builder._carBrakeDistanceMin(Double.valueOf(result1[0]))._carBrakeDistanceMax(Double.valueOf(result1[1]));		  	        		
		  	        	}

		  	        }
		  	      });
	    m.add("Traffic light green time",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	String[] result1 = _ui.processForm(_getMinMax);
		  	        	if(checkMinMax(result1)){
		  	        		_builder=_builder._lightGreenTimeMin(Double.valueOf(result1[0]))._lightGreenTimeMax(Double.valueOf(result1[1]));        		
		  	        	}

		  	        }
		  	      });
	    m.add("Traffic light yellow time",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	String[] result1 = _ui.processForm(_getMinMax);
		  	        	if(checkMinMax(result1)){
		  	        		_builder=_builder._lightYellowTimeMin(Double.valueOf(result1[0]))._lightYellowTimeMax(Double.valueOf(result1[1]));		  	        		
		  	        	}

		  	        }
		  	      });
	    m.add("Reset simulation and return to the main menu",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	_state = EXIT;
		  	        }
		  	      });
	    
	    
	    
	    _menus[stateNum] = m.toUIMenu("");
	  }
	  private void addEXIT(int stateNum) {
	    UIMenuBuilder m = new UIMenuBuilder();
	    
	    m.add("Default", new UIMenuAction() { public void run() {} });
	    m.add("Yes",
	      new UIMenuAction() {
	        public void run() {
	          _state = EXITED;
	        }
	      });
	    m.add("No",
	      new UIMenuAction() {
	        public void run() {
	          _state = START;
	        }
	      });
	    
	    _menus[stateNum] = m.toUIMenu("Are you sure you restart the simulation with the new settings?");
	  }
	}