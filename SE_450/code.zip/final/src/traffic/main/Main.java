package traffic.main;


import traffic.data.SettingsData;
import traffic.main.Control1;
import traffic.ui.UI;

public class Main {
	  private Main() {}
	  public static void main(String[] args) {
		  UI ui= new traffic.ui.TextUI(); 
		  Control1 control = new Control1(new SettingsData.SettingsDataBuilder().build(), ui);
		  control.run();
	  }
}