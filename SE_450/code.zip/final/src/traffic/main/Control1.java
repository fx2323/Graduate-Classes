package traffic.main;





import traffic.model.Model;
import traffic.model.swing.SwingAnimatorBuilder;
import traffic.ui.*;
import traffic.data.SettingsData;



class Control1 {
	  private static final int EXITED = 0;
	  private static final int EXIT = 1;
	  private static final int START = 2;
	  private static final int NUMSTATES = 10;
	  private UIMenu[] _menus;
	  private int _state;
	    
	  private SettingsData _settings;
	  private UI _ui;
	  
	  Control1(SettingsData settingsData, UI ui) {
		_settings = settingsData;
	    _ui = ui;

	    _menus = new UIMenu[NUMSTATES];
	    _state = START;
	    addSTART(START);
	    addEXIT(EXIT);
	    
	  }
	 



	void run() {
	    try {
	      while (_state != EXITED) {
	        _ui.processMenu(_menus[_state]);
	      }
	    } catch (UIError e) {
	      _ui.displayError("UI closed");
	    }
	  }
	  
	  private void addSTART(int stateNum) {
	    UIMenuBuilder m = new UIMenuBuilder();
	    
	    m.add("Default",
	      new UIMenuAction() {
	        public void run() {
	          _ui.displayError("doh!");
	        }
	      });
	    m.add("Run simulation",
	      new UIMenuAction() {
	        public void run() {
  	        	Model m = new Model(new SwingAnimatorBuilder(), _settings);
  	        	m.run();
  	        	m.dispose();
	        }
	      });

	    m.add("Change simulation parameters",
		  	      new UIMenuAction() {
		  	        public void run() {
		  			  UI ui= new traffic.ui.TextUI(); 
		  			  Control2 control = new Control2(_settings, ui);
		  			  control.run();
		  			  _settings=control.getSettings();
		  			  Model m = new Model(new SwingAnimatorBuilder(), _settings);
		  			  m.run();
		  			  m.dispose();

		  	        }
		  	      });
	    m.add("Exit",
		  	      new UIMenuAction() {
		  	        public void run() {
		  	        	_state = EXIT;
		  	        }
		  	      });
	    
	    
	    
	    _menus[stateNum] = m.toUIMenu("");
	  }
	  private void addEXIT(int stateNum) {
	    UIMenuBuilder m = new UIMenuBuilder();
	    
	    m.add("Default", new UIMenuAction() { public void run() {} });
	    m.add("Yes",
	      new UIMenuAction() {
	        public void run() {
	          _state = EXITED;
	        }
	      });
	    m.add("No",
	      new UIMenuAction() {
	        public void run() {
	          _state = START;
	        }
	      });
	    
	    _menus[stateNum] = m.toUIMenu("Are you sure you want to exit?");
	  }
	}